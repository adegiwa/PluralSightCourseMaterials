# (optional) get connected and pick the subscription we are working with
# Login-AzureRmAccount
# Select-AzureRmSubscription -SubscriptionName "MySubscription"

# Get hold of the key for our storage container
$resourceGroupName = "whosplaying"
$storageAccountName = "whosplaying"
$storageKeys = Get-AzureRmStorageAccountKey -ResourceGroupName $resourceGroupName `
                                            -Name $storageAccountName
$key = $storageKeys.value[0]

# use azCopy
$azCopy = "C:\Program Files (x86)\Microsoft SDKs\Azure\AzCopy\AzCopy.exe"
$websiteFolder = ".\..\web2"
$containerName = "web"

. $azCopy /Source:$websiteFolder `
        /Dest:https://$storageAccountName.blob.core.windows.net/$containerName/ `
        /DestKey:$key /S /Y /SetContentType