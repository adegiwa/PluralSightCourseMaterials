{
    "EventDateAndTime": "2017-06-28T16:00:00Z",
    "Location": "Wildern School",
    "MyResponse":"yes",
    "Responses": [
        { "Name": "Mark", "Playing": "yes" },
        { "Name": "Jon", "Playing": "yes" },
        { "Name": "Dan", "Playing": "yes" },
        { "Name": "Dawkins", "Playing": "yes" },
        { "Name": "Martin", "Playing": "yes" },
        { "Name": "Paul", "Playing": "yes" },
        { "Name": "Tom W", "Playing": "yes" },
        { "Name": "Nick", "Playing": "yes" },
        { "Name": "Conrad", "Playing": "yes" },
        { "Name": "James", "Playing": "maybe" },
        { "Name": "Neil", "Playing": "maybe" },
        { "Name": "Adam", "Playing": "no" },
        { "Name": "Tom K", "Playing": "unknown" },
        { "Name": "Tim", "Playing": "unknown" }
    ]
}